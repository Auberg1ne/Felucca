/* SPDX-License-Identifier: GPL-3.0-only */
/* C2/C3 regression: actual allocator, upload and ERASE handlers on physical NOR.
 * cc -O1 -w -Ibuild/gen -Ifirmware/src
 *    tests/sample_delete_test.c -lm -o build/host/sample_delete_test
 * Uses the same flat-memory XIP rebasing as the existing sample host tests. */
#include <stdint.h>
#include <setjmp.h>
#include <assert.h>
#include "../firmware/hal/fm1_xip.h"
static uint8_t nor[0x100000], saved[sizeof nor];
static const uint8_t *host_sample_ptr(uint32_t off);
#define fm1_xip_ptr host_sample_ptr
#define FELUCCA_OTA 1
#define FELUCCA_FLASH 0
#define FELUCCA_VERSION "TEST"
#define FELUCCA_CDC 1                                    /* (as the firmware: MENU > USB SERIAL switches the console) */
#define main hostsim_main
#include "hostsim.c"
#undef main
#define MENU_N (32u + FELUCCA_CPU2)                  /* 1.6.1 (core.h FELUCCA_CPU2, the default): 2ND CORE, id 32 */

static uint32_t host_progress = 1;
static uint8_t host_wire[4096];
static uint32_t host_wire_n;
static void host_drain(void)
{
    while (so_r != so_w) {
        uint32_t p = sx_out_q[so_r++ % SXQ], cin = p & 15u, i;
        uint32_t n = cin == 4u || cin == 7u ? 3u : cin == 6u ? 2u : 1u;
        for (i = 0; i < n && host_wire_n < sizeof host_wire; i++)
            host_wire[host_wire_n++] = (uint8_t)(p >> (8u * (i + 1u)));
    }
}
static uint32_t ota_now_ms(void) { return fm1_ms; }
static void ota_idle(void) { host_drain(); fm1_ms++; }
static void fm1_wdt_feed(void)
{
    fm1_ms++;
    if (host_progress && transport_req == 2u) { seq_stop(); transport_req = 0; }
}
static void fm1_irq_off(void) {}
static void fm1_irq_on(void) {}
static int32_t fm1_enc_take(uint32_t e) { (void)e; return 0; }
static void lcd_sync(void) {}
static void lcd_power(uint32_t s) { (void)s; }   /* (MENU > SCREEN OFF: lcd.c) */
static void lcd_wake_now(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ (void)x; (void)y; (void)w; (void)h; (void)p; }
#include "../firmware/src/gfx.c"
#include "../firmware/src/panel.c"
#include "../firmware/src/ui.c"
#include "../firmware/src/menu_items.c"
static void panel_setup(void) {}
#include "../firmware/src/upreset.c"
#include "../firmware/src/project.c"

static uint32_t flash_ok = 1;
static void audio_silence(void) {}
static uint32_t bad_phys, pending_phys, pending_len;
static uint8_t bad_sector[4096], pending_data[32];
static int bad_read_active, silent_erase, fault_mode, committed_write;
static uint32_t fault_op, record_op, record_phys;
static uint32_t writes, write_off[8], write_len[8], erased_phys, erases, xip_reads;
static const uint8_t *host_sample_ptr(uint32_t off)
{
    assert(off < sizeof nor);
    xip_reads++;
    return bad_read_active && off == bad_phys ? bad_sector : nor + off;
}
static void fl_inval(uint32_t off, uint32_t n)
{
    if (fault_mode == 5 && committed_write && record_op == fault_op && off == record_phys && n == 32) {
        bad_phys = off; memcpy(bad_sector, nor + off, sizeof bad_sector);
        bad_sector[28] ^= 1u; bad_read_active = 1;
    }
}
static jmp_buf power_cut;
static int budget = -1, protected_write, erase_error, lost_ack;

static void tick_before(void) { if (budget == 0) longjmp(power_cut, 1); }
static void tick_after(void) { if (budget > 0 && --budget == 0) longjmp(power_cut, 1); }
static void bounds(uint32_t off, uint32_t n)
{
    assert(off >= SMP_USER_BASE && n <= SMP_USER_POOL_SIZE &&
           off - SMP_USER_BASE <= SMP_USER_POOL_SIZE - n);
}
static int fl_erase4k(uint32_t off, uint32_t *took)
{
    bounds(off, SMP_USER_SECTOR_SIZE); assert(!(off & 4095u));
    erased_phys = off; *took = 0; erases++;
    if (erase_error) return 1;
    if (silent_erase) return 0;
    for (uint32_t i = 0; i < 4096; i++) {
        tick_before(); nor[off + i] = 255; tick_after();
    }
    return 0;
}
static int fl_write(uint32_t off, const void *src, uint32_t n)
{
    const uint8_t *p = src;
    bounds(off, n);
    if (writes < 8) { write_off[writes] = off; write_len[writes] = n; }
    writes++;
    int body = n == 28 && off < SMP_USER_BASE + SMP_USER_SECTOR_SIZE;
    if (body) {
        memcpy(&record_op, src, 4); record_phys = off; committed_write = 0;
        if (record_op == fault_op && fault_mode == 1) return 1;
    }
    int marker = n == 4 && off == record_phys + 28;
    if (marker && record_op == fault_op && fault_mode == 4) {
        pending_phys = off; pending_len = n; memcpy(pending_data, src, n); return 1;
    }
    /* Same page splitting as fl_write in fm1_flash.h; no zero-to-one writes. */
    while (n) {
        uint32_t chunk = 256u - (off & 255u);
        if (chunk > n) chunk = n;
        for (uint32_t i = 0; i < chunk; i++) {
            tick_before();
            assert((nor[off] & *p) == *p);
            if (protected_write != 1 && !(protected_write == 2 && writes == 2)) nor[off] &= *p;
            off++; p++; tick_after();
        }
        n -= chunk;
    }
    if (marker) committed_write = 1;
    if (record_op == fault_op && ((fault_mode == 2 && body) || (fault_mode == 3 && marker))) return 1;
    return lost_ack && writes == (uint32_t)lost_ack ? 1 : 0;
}
static int st_read(uint32_t off, void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int st_prog(uint32_t off, const void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int st_erase(uint32_t off) { (void)off; return -1; }
#include "../firmware/src/storage.c"
#include "../firmware/src/editor.c"
static int failures;
static void check(const char *s, int ok)
{ printf("sample delete: %s %s\n", s, ok ? "ok" : "FAIL"); failures += !ok; }
static void reboot(void)
{
    memset(ed_smp_stage_phys, 0, sizeof ed_smp_stage_phys);
    memset(ed_smp_stage_sectors, 0, sizeof ed_smp_stage_sectors);
    memset(ed_smp_stage_capacity, 0, sizeof ed_smp_stage_capacity);
    memset(ed_smp_stage_data_len, 0, sizeof ed_smp_stage_data_len);
    flash_ok = 1; bad_read_active = committed_write = 0;
    smp_user_alloc_boot();
    for (uint32_t k = 0; k < SMP_USER_SLOTS; k++) smp_user_scan(k);
}
static void fresh(void)
{
    memset(nor, 255, sizeof nor); budget = -1;
    protected_write = erase_error = lost_ack = silent_erase = fault_mode = 0;
    fault_op = record_op = 0;
    pending_len = 0; writes = erases = 0;
    song.playing = 0; transport_req = 0;
    reboot();
}
static uint32_t pack(const void *v, uint32_t n, uint8_t *out)
{
    const uint8_t *p = v; uint32_t at = 0;
    while (n) {
        uint32_t k = n > 7 ? 7 : n; uint8_t mask = 0;
        for (uint32_t j = 0; j < k; j++) mask |= (p[j] >> 7) << j;
        out[at++] = mask;
        for (uint32_t j = 0; j < k; j++) out[at++] = p[j] & 127;
        p += k; n -= k;
    }
    return at;
}
static smp_user_hdr_t header(uint8_t data)
{
    smp_user_hdr_t h = {0}; uint8_t payload[256]; memset(payload, data, sizeof payload);
    h.magic = SMP_USER_MAGIC; h.version = 1; h.nz = 1; h.data_len = 256;
    h.crc = st_crc32(payload, sizeof payload);
    h.zone[0].n = 512; h.zone[0].le = 511; h.zone[0].rate = 65536; h.zone[0].hi = 127;
    return h;
}
static int upload(uint32_t k, uint8_t data)
{
    uint8_t packed[600], payload[256]; smp_user_hdr_t h = header(data);
    memset(payload, data, sizeof payload);
    if (ed_smp_begin(k, sizeof payload)) return 1;
    if (fl_write(ed_smp_stage_phys[k] + SMP_USER_DATA, payload, sizeof payload)) return 1;
    return ed_smp_end(k, packed, pack(&h, sizeof h, packed));
}
static void legacy(uint32_t k, uint8_t data)
{
    uint32_t phys = SMP_USER_BASE + k * SMP_USER_SIZE;
    smp_user_hdr_t h = header(data);
    memcpy(nor + phys, &h, sizeof h);
    memset(nor + phys + SMP_USER_DATA, data, h.data_len);
}
static int gone(uint32_t k)
{ return smp_user_deleted[k] && !smp_user_phys[k] && !usr_nz[k]; }
static int erase_request(uint32_t k)
{
    const uint8_t frame[] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_ERASE, (uint8_t)k};
    host_wire_n = 0; ed_handle(frame, sizeof frame); host_drain();
    return host_wire_n == 8 && host_wire[5] == k ? host_wire[6] : -1;
}
static int write_page(uint32_t k, uint32_t off, const uint8_t *page, uint32_t len)
{
    uint8_t f[640] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_WRITE};
    f[4] = (uint8_t)k; f[5] = off & 127; f[6] = (off >> 7) & 127; f[7] = (off >> 14) & 127;
    host_wire_n = 0; ed_handle(f, 8 + pack(page, len, f + 8)); host_drain();
    return host_wire_n == 11 ? host_wire[9] : -1;
}
static void finish_late(void)
{
    for (uint32_t i = 0; i < pending_len; i++) {
        assert((nor[pending_phys + i] & pending_data[i]) == pending_data[i]);
        nor[pending_phys + i] &= pending_data[i];
    }
    pending_len = 0;
}
static int locked_mutations(uint32_t k)
{
    uint32_t w = writes, e = erases, p = ed_smp_stage_phys[k], c = smp_stage_count[k];
    uint8_t bits[sizeof smp_user_occupied], packed[600], payload[256] = {0};
    smp_user_hdr_t h = header(0x11); memcpy(bits, smp_user_occupied, sizeof bits);
    int ok = ed_smp_begin(k, 256) != 0 && erase_request(k) != 0 && ed_smp_erase(k) != 0 &&
        ed_smp_end(k, packed, pack(&h, sizeof h, packed)) != 0 && write_page(k, 512, payload, 256) != 0;
    ed_smp_stage_abort(k); smp_user_stage_abort(k);
    return ok && w == writes && e == erases && p == ed_smp_stage_phys[k] &&
        c == smp_stage_count[k] && !memcmp(bits, smp_user_occupied, sizeof bits);
}
static smp_alloc_desc_t fake_tomb(uint32_t slot, uint32_t gen)
{
    smp_alloc_desc_t d = {0}; d.magic = SMP_ALLOC_DELETE_MAGIC; d.version = 1;
    d.logical_slot = (uint8_t)slot; d.sector_count = 1; d.generation = gen;
    d.commit = SMP_ALLOC_COMMITTED; d.record_crc = st_crc32(&d, 28);
    return d;
}
static void payload_provenance(void)
{
    /* Exact original sequence, then other offsets, slots, and metadata magics. */
    for (uint32_t offset = 1; offset <= 4; offset++) {
        fresh(); assert(!upload(0, 0x11)); assert(!upload(2, 0x33)); reboot();
        uint32_t old0 = smp_user_phys[0], old2 = smp_user_phys[2];
        assert(!ed_smp_begin(1, 4 * 4096));
        smp_alloc_desc_t fake = fake_tomb(0, smp_user_generation[0] + 1);
        uint8_t page[256]; memset(page, 255, sizeof page); memcpy(page + 224, &fake, sizeof fake);
        check("unfinished slot-1 tombstone-like page is accepted only as audio", !write_page(1, offset * 4096 + 256, page, 256));
        reboot();
        check("reboot never deletes or releases committed slot 0", usr_nz[0] && smp_user_phys[0] == old0 &&
              !smp_user_deleted[0] && smp_alloc_test((old0 - SMP_USER_BASE) / 4096));
        check("cross-slot sample and unfinished ownership remain protected", usr_nz[2] && smp_user_phys[2] == old2 && !usr_nz[1]);
        uint32_t claims = 0; for (uint32_t s = 0; s < 60; s++) claims += smp_alloc_test(s);
        check("unfinished claims are not recycled on reboot", claims == 8);
    }
    /* A complete nested FSMP/SMA1 can also be arbitrary ADPCM bytes. */
    fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
    assert(!ed_smp_begin(1, 8192)); uint8_t nested[768]; memset(nested, 255, sizeof nested);
    smp_user_hdr_t h = header(0x22); memcpy(nested, &h, sizeof h); memset(nested + 512, 0x22, 256);
    smp_alloc_desc_t d = {0}; d.magic = SMP_ALLOC_MAGIC; d.version = SMP_ALLOC_VERSION; d.logical_slot = 0;
    d.sector_count = 1; d.generation = 99; d.data_len = 256; d.data_crc = h.crc;
    d.reserved = st_crc32(nested, 480);
    d.commit = SMP_ALLOC_COMMITTED; d.record_crc = st_crc32(&d, 28); memcpy(nested + 480, &d, sizeof d);
    for (uint32_t p = 0; p < sizeof nested; p += 256) assert(!write_page(1, 4096 + p, nested + p, 256));
    uint32_t nested_phys = ed_smp_stage_phys[1] + 4096;
    check("H2 nested counterfeit v2 descriptor and header are internally CRC-valid", smp_alloc_extent_valid(nested_phys, 0,
        (const smp_alloc_desc_t *)(nor + nested_phys + 480), d.reserved));
    reboot(); check("complete SMA1 header embedded in unfinished audio has no authority", usr_nz[0] && smp_user_phys[0] == old && !usr_nz[1]);
    /* Journal-shaped payload is not in the anchored metadata sector. */
    assert(!ed_smp_begin(1, 8192)); d = fake_tomb(0, 99); d.magic = SMP_JOURNAL_DELETE;
    d.sector_count = 0; d.record_crc = 0; d.record_crc = st_crc32(&d, 28);
    uint8_t page[256]; memset(page, 255, sizeof page); memcpy(page, &d, sizeof d);
    assert(!write_page(1, 4096, page, 256)); reboot();
    check("SMJD bytes outside the protected root cannot delete a sample", usr_nz[0] && smp_user_phys[0] == old);
    assert(!ed_smp_begin(1, 8192)); d = smp_journal_header(); d.commit = SMP_ALLOC_COMMITTED;
    memset(page, 255, sizeof page); memcpy(page, &d, sizeof d); assert(!write_page(1, 4096, page, 256)); reboot();
    check("SMJ1-shaped audio cannot replace the fixed root", usr_nz[0] && smp_user_phys[0] == old && smp_journal_state == SMP_JOURNAL_READY);
    /* Also publish a complete, valid outer sample containing nested records. */
    assert(!ed_smp_begin(1, 8192));
    static uint8_t audio[8192]; memset(audio, 0x11, sizeof audio);
    d = fake_tomb(0, 0x7FFFFFFFu); memcpy(audio + 4096 + 480 - 512, &d, sizeof d);
    for (uint32_t p = 0; p < sizeof audio; p += 256) assert(!write_page(1, 512 + p, audio + p, 256));
    h = header(0x11); h.data_len = sizeof audio; h.crc = st_crc32(audio, sizeof audio);
    h.zone[0].n = sizeof audio * 2; h.zone[0].le = h.zone[0].n - 1;
    uint8_t packed[600]; assert(!ed_smp_end(1, packed, pack(&h, sizeof h, packed))); reboot();
    check("published audio still grants no authority to its nested tombstone", usr_nz[1] && usr_nz[0] && smp_user_phys[0] == old);
    assert(!ed_smp_begin(1, 256)); writes = 0;
    check("client cannot address the journal through WRITE", write_page(1, 0, page, 256) != 0 &&
          write_page(1, 256, page, 256) != 0 && write_page(1, 0x1FFF00, page, 256) != 0 && !writes);
    fresh(); assert(!ed_smp_journal_ready()); smp_alloc_release(0); writes = erases = 0;
    check("allocator cannot return the root even if its bitmap bit is cleared", ed_smp_begin(0, 256) != 0 && !writes && !erases);
}
static void fault_tests(void)
{
    const uint32_t ops[] = {SMP_JOURNAL_CLAIM, SMP_JOURNAL_PUBLISH, SMP_JOURNAL_DELETE};
    for (uint32_t op = 0; op < 3; op++) for (int mode = 1; mode <= 5; mode++) {
        fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
        if (op == 1) { assert(!ed_smp_erase(0)); reboot(); }
        fault_op = ops[op]; fault_mode = mode;
        int rc = op == 0 ? ed_smp_begin(1, 256) : op == 1 ? upload(0, 0x22) : ed_smp_erase(0);
        check("uncertain journal operation fails and disables storage", rc != 0 && !flash_ok && smp_user_io_blocked);
        check("repeated ERASE, WRITE, abort and allocations retain uncertainty", locked_mutations(op == 0 ? 1 : 0) && locked_mutations(2));
        if (mode == 4) finish_late();
        fault_mode = 0; bad_read_active = 0; reboot();
        if (mode <= 2) {
            check("torn journal tail is quarantined without any sector reuse", smp_journal_state == SMP_JOURNAL_LOCKED ||
                  (mode == 1 && smp_journal_state == SMP_JOURNAL_READY));
        } else if (op == 0) check("recovered claim never publishes payload", usr_nz[0] && smp_user_phys[0] == old && !usr_nz[1]);
        else if (op == 1) {
            check("reboot reconciles a committed but unacknowledged publish", usr_nz[0] && !smp_user_deleted[0]);
            assert(!ed_smp_erase(0)); reboot(); check("ERASE after publish reconciliation stays durable", gone(0));
        } else check("reboot reconciles a committed but unacknowledged deletion", gone(0));
        check("original sample bytes survive the failed operation", nor[old + 512] == 0x11);
    }
    fresh(); assert(!ed_smp_begin(0, 256)); writes = 0; lost_ack = 1;
    uint8_t page[256]; memset(page, 0x11, sizeof page);
    check("payload I/O errors retain claim and block further mutation", write_page(0, 512, page, 256) != 0 && locked_mutations(0));
}
static void power_tests(void)
{
    /* DELETE is append-only: 28 body bytes + 4 commit bytes, no erase. */
    fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0]; memcpy(saved, nor, sizeof nor);
    int ok = 1;
    for (int cut = 0; cut <= 32; cut++) {
        memcpy(nor, saved, sizeof nor); budget = -1; reboot(); budget = cut;
        if (!setjmp(power_cut)) (void)ed_smp_erase(0);
        budget = -1; reboot();
        ok &= cut == 32 ? gone(0) : (usr_nz[0] || smp_journal_state == SMP_JOURNAL_LOCKED);
        ok &= !memcmp(nor + old, saved + old, 4096) && smp_alloc_test((old - SMP_USER_BASE) / 4096);
    }
    check("33 deletion power cuts preserve data and never reuse old extents", ok);
    /* A claim commits before its data sector is erased. */
    fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0]; memcpy(saved, nor, sizeof nor); ok = 1;
    for (int cut = 0; cut <= 32 + 4096; cut++) {
        memcpy(nor, saved, sizeof nor); budget = -1; reboot(); budget = cut;
        if (!setjmp(power_cut)) (void)ed_smp_begin(1, 256);
        budget = -1; reboot();
        ok &= !usr_nz[1] && (usr_nz[0] || smp_journal_state == SMP_JOURNAL_LOCKED) &&
              !memcmp(nor + old, saved + old, 4096) && smp_alloc_test((old - SMP_USER_BASE) / 4096);
    }
    check("4129 claim/erase power cuts never expose uncommitted audio", ok);
    /* SMA1 plus journal PUBLISH; only the latter grants recovery authority. */
    fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0];
    assert(!ed_smp_begin(0, 256)); uint8_t data[256], packed[600]; memset(data, 0x22, 256);
    assert(!write_page(0, 512, data, 256)); smp_user_hdr_t h = header(0x22); uint32_t n = pack(&h, sizeof h, packed);
    uint32_t stage = ed_smp_stage_phys[0], count = ed_smp_stage_sectors[0]; memcpy(saved, nor, sizeof nor); ok = 1;
    for (int cut = 0; cut <= 544; cut++) {
        memcpy(nor, saved, sizeof nor); budget = -1; reboot();
        /* Resume the known in-session stage handle for fault injection only. */
        ed_smp_stage_phys[0] = stage; ed_smp_stage_sectors[0] = count; ed_smp_stage_capacity[0] = count * 4096;
        ed_smp_stage_data_len[0] = 256; smp_stage_start[0] = (stage - SMP_USER_BASE) / 4096; smp_stage_count[0] = count;
        budget = cut;
        if (!setjmp(power_cut)) (void)ed_smp_end(0, packed, n);
        budget = -1; reboot();
        ok &= cut == 544 ? (smp_user_phys[0] == stage) :
            (smp_user_phys[0] == old || smp_journal_state == SMP_JOURNAL_LOCKED);
        ok &= !memcmp(nor + old, saved + old, 4096) && smp_alloc_test((old - SMP_USER_BASE) / 4096);
    }
    check("545 publish power cuts never authorize SMA1 without journal commit", ok);
    ok = 1;
    for (int cut = 0; cut <= 32; cut++) {
        fresh(); budget = cut;
        if (!setjmp(power_cut)) (void)ed_smp_journal_ready();
        budget = -1; reboot();
        ok &= !usr_nz[0] && !usr_nz[1] && !usr_nz[2];
        ok &= cut == 0 ? smp_journal_state == SMP_JOURNAL_BLANK :
            cut == 32 ? smp_journal_state == SMP_JOURNAL_READY : smp_journal_state == SMP_JOURNAL_LOCKED;
    }
    check("33 anchor power cuts cannot manufacture a sample or free occupied data", ok);
}
/* C3: no raw byte pattern is sufficient authority to publish a sample. */
static int quarantined(void)
{
    int ok = smp_journal_state == SMP_JOURNAL_QUARANTINED;
    for (uint32_t k = 0; k < SMP_USER_LOGICAL_SLOTS; k++) {
        smp_user_scan(k);
        ok &= !smp_user_phys[k] && !smp_user_sectors[k] && !usr_nz[k] && smp_user_unresolved[k];
        for (uint32_t z = 0; z < 16; z++) ok &= !usr_zone[k][z].n;
    }
    for (uint32_t s = 0; s < 60; s++) ok &= smp_alloc_test(s);
    return ok;
}
static int no_exports_allow_reads(int allow_reads)
{
    uint32_t reads = xip_reads;
    uint8_t info[] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_INFO};
    host_wire_n = 0; ed_handle(info, sizeof info); host_drain();
    int ok = host_wire_n == 8 + SMP_USER_SLOTS * 3;
    for (uint32_t i = 7; i + 1 < host_wire_n; i++) ok &= host_wire[i] == 0;
    for (uint32_t k = 0; k < SMP_USER_SLOTS; k++) {
        uint32_t len = 999;
        ok &= ed_bk_object(32 + k, &len) == 0 && len == 0;
        uint8_t get[] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_BACKUP_GET, 32 + k, 0, 0, 0, 0, 0, 16, 0};
        ed_bk_valid = 1; ed_bk_usb = usb.resets;
        host_wire_n = 0; ed_handle(get, sizeof get); host_drain();
        ok &= host_wire_n > 7 && host_wire_n < 24 && host_wire[6] != 0;
    }
    return ok && (allow_reads || reads == xip_reads);
}
static int no_exports(void) { return no_exports_allow_reads(0); }
static void quarantine_tests(void)
{
    fresh(); legacy(0, 0x11); legacy(1, 0x22); legacy(2, 0x33);
    smp_alloc_desc_t tomb = fake_tomb(0, 8);
    memcpy(nor + SMP_USER_BASE + 6 * 4096 + 480, &tomb, sizeof tomb);
    memcpy(saved, nor, sizeof nor); reboot();
    check("C3 genuine legacy images quarantined without publication", quarantined());
    check("C3 INFO and backup expose no quarantined content", no_exports());
    int ok = 1;
    for (uint32_t boot = 0; boot < 3; boot++) {
        reboot(); ok &= quarantined();
        for (uint32_t k = 0; k < SMP_USER_LOGICAL_SLOTS; k++) {
            /* Even a stale live handle cannot bypass the mutation gates. */
            ed_smp_stage_phys[k] = SMP_USER_BASE + 4096;
            ed_smp_stage_sectors[k] = smp_stage_count[k] = 1;
            ed_smp_stage_capacity[k] = 4096;
            ok &= locked_mutations(k);
        }
    }
    check("C3 repeated boots and stale-handle mutations never write", ok && !writes && !erases && !memcmp(saved, nor, sizeof nor));
    project_t project;
    memset(&project, 0, sizeof project);
    project.magic = PROJ_MAGIC; project.size = sizeof project;
    project.parts = NPART; project.phys = PROJ_PHYS; chain_defaults(&project.chain);
    for (uint32_t k = 0; k < NTRK; k++) {
        uint32_t eng = k == 1 ? ENGI_GRAIN : ENGI_SAMPLE;
#if FELUCCA_SLICE
        if (k == 2) eng = 13;
#endif
        project.t[k].engine = eng;
        for (uint32_t p = 0; p < P_COUNT; p++) project.t[k].p[p] = param_desc_of(eng, p)->def;
        project.t[k].p[P_E0] = eng == 13 ? 1 : SMP_NSETS;
        memcpy(project.fm6[k], FM6_INIT, FM6_PACKED);
    }
    project.sum = proj_sum(&project);
    ok = !project_restore_runtime(&project);
    for (uint32_t k = 0; k < NTRK; k++) {
        uint32_t code;
        ok &= snd_missing(&trk[k], &code) != 0;
    }
    check("C3 project restore cannot authorize quarantined engine sources", ok && quarantined() && !writes && !erases);
    /* Completed old header, cut before any SMA1 byte: indistinguishable from legacy.
     * Check every byte-prefix cut through header, descriptor body and COMT. */
    uint8_t image[512]; smp_user_hdr_t h = header(0x22);
    memset(image, 255, sizeof image); memcpy(image, &h, sizeof h);
    smp_alloc_desc_t d = {0}; d.magic = SMP_ALLOC_MAGIC; d.version = 1; d.logical_slot = 7;
    d.sector_count = 1; d.generation = 9; d.data_len = 256; d.data_crc = h.crc;
    d.commit = SMP_ALLOC_COMMITTED; d.record_crc = st_crc32(&d, 28);
    memcpy(image + 480, &d, sizeof d);
    ok = 1;
    for (uint32_t boundary = 0; boundary < 3; boundary++) {
        for (uint32_t cut = 0; cut <= sizeof image; cut++) {
            fresh(); uint32_t phys = SMP_USER_BASE + boundary * SMP_USER_SIZE;
            memset(nor + phys + 512, 0x22, 256); memcpy(nor + phys, image, cut);
            memcpy(saved, nor, sizeof nor); reboot();
            ok &= (smp_journal_state == SMP_JOURNAL_QUARANTINED || smp_journal_state == SMP_JOURNAL_LOCKED) &&
                !smp_user_phys[boundary] && !usr_nz[boundary] && !smp_user_phys[7] &&
                !writes && !erases && !memcmp(saved, nor, sizeof nor);
            for (uint32_t s = 0; s < 60; s++) ok &= smp_alloc_test(s);
        }
    }
    check("C3 all legacy boundaries and 513 header/descriptor cuts fail closed", ok);
    /* Complete counterfeit samples in an unfinished outer upload. */
    ok = 1;
    for (uint32_t k = 0; k < 8; k++) {
        fresh(); legacy(0, 0x11);
        d.logical_slot = k; d.generation = k & 1 ? 0x80000000u : 0xFFFFFFFFu;
        d.record_crc = 0; d.record_crc = st_crc32(&d, 28);
        memcpy(image + 480, &d, sizeof d);
        for (uint32_t sector = 2; sector <= 6; sector += 2) {
            memcpy(nor + SMP_USER_BASE + sector * 4096, image, sizeof image);
            memset(nor + SMP_USER_BASE + sector * 4096 + 512, 0x22, 256);
        }
        memcpy(saved, nor, sizeof nor); reboot();
        ok &= quarantined() && no_exports() && !memcmp(saved, nor, sizeof nor) && !writes && !erases;
    }
    check("C3 counterfeit committed SMA1 across slots and sector offsets stays quarantined", ok);
    /* Defense in depth: consumer gates also reject stale RAM publication state. */
    usr_nz[0] = 1; smp_user_phys[0] = SMP_USER_BASE; smp_user_sectors[0] = 1;
    check("C3 export guards reject stale published metadata", no_exports());
    smp_user_scan(0);
    check("C3 scan clears stale SAMPLE GRAIN and SLICE publication", !usr_nz[0] && !usr_zone[0][0].n &&
        smp_set_missing(SMP_NSETS) && !gr_nz(SMP_NSETS)
#if FELUCCA_SLICE
        && !slc_get(1)
#endif
    );
}
static void anchored_visibility_tests(void)
{
    fresh();
    int ok = smp_journal_state == SMP_JOURNAL_BLANK;
    for (uint32_t k = 0; k < 8; k++) ok &= !upload(k, 0x11 + k);
    reboot();
    for (uint32_t k = 0; k < 8; k++) {
        smp_user_scan(k);
        ok &= usr_nz[k] == 1 && usr_zone[k][0].n == 512 && !smp_user_unresolved[k] &&
            smp_user_phys[k] >= SMP_USER_BASE + 4096 && smp_alloc_test((smp_user_phys[k] - SMP_USER_BASE) / 4096) &&
            *fm1_xip_ptr(smp_user_phys[k] + 512) == 0x11 + k;
    }
    track_t track = {0}; voice_t voice = {0};
    track.p[P_E0] = SMP_NSETS; voice.note = 60;
    sample_note_on(&track, &voice);
    uint32_t len = 0;
    const uint8_t *backup = ed_bk_object(32, &len);
    ok &= !voice.s[6] && voice.s[4] == 0x8000 && gr_nz(SMP_NSETS) == 1 &&
        backup == fm1_xip_ptr(smp_user_phys[0]) && len == 768;
#if FELUCCA_SLICE
    ok &= slc_get(1) != 0;
#endif
    check("C3 anchored publication for all eight slots retains engine and backup access", ok && smp_journal_state == SMP_JOURNAL_READY);
}
static int all_reserved(void)
{
    for (uint32_t s = 0; s < SMP_USER_SECTOR_COUNT; s++) if (!smp_alloc_test(s)) return 0;
    return 1;
}
static void seal_record(smp_alloc_desc_t *d)
{ d->commit = SMP_ALLOC_COMMITTED; d->record_crc = 0; d->record_crc = st_crc32(d, 28); }
static void journal_rejection_tests(void)
{
    const uint32_t generations[] = {0, 1, 3, 0x80000001u, 0xFFFFFFFFu};
    for (uint32_t i = 0; i < sizeof generations / sizeof generations[0]; i++) {
        fresh(); assert(!upload(0, 0x11)); reboot();
        uint32_t old = smp_user_phys[0]; smp_alloc_desc_t d = {0};
        d.magic = SMP_JOURNAL_CLAIM; d.version = 1; d.logical_slot = 0; d.sector_count = 1;
        d.generation = generations[i]; d.data_len = 256; d.reserved = 2; seal_record(&d);
        memcpy(nor + SMP_USER_BASE + smp_journal_next, &d, sizeof d); reboot();
        check("duplicate, skipped, half-range or wrapped journal generations fail closed", smp_journal_state == SMP_JOURNAL_LOCKED &&
              all_reserved() && !usr_nz[0] && nor[old + 512] == 0x11 && locked_mutations(0));
    }
    for (int mode = 0; mode < 10; mode++) {
        fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
        smp_alloc_desc_t d = {0}; d.magic = SMP_JOURNAL_CLAIM; d.version = 1;
        d.logical_slot = 1; d.sector_count = 1; d.generation = 1; d.data_len = 256; d.reserved = 2;
        if (mode == 0) d.reserved = 1;                   /* overlaps existing claim */
        if (mode == 1) d.magic = SMP_JOURNAL_PUBLISH;    /* no preceding claim */
        if (mode == 2) d.reserved = 0;                   /* tries to claim root */
        if (mode == 6) d.reserved = SMP_USER_SECTOR_COUNT;
        if (mode == 7) d.sector_count = SMP_USER_SECTOR_COUNT;
        if (mode == 8) d.data_len = SMP_USER_SECTOR_SIZE;
        if (mode == 9) d.version = 2;
        seal_record(&d);
        if (mode == 3) d.record_crc ^= 1;
        if (mode == 4) d.commit ^= 1;
        uint32_t off = smp_journal_next + (mode == 5 ? 32 : 0); /* forbidden hole */
        memcpy(nor + SMP_USER_BASE + off, &d, sizeof d); reboot();
        check("rejected metadata never releases any previously occupied sector", smp_journal_state == SMP_JOURNAL_LOCKED &&
              all_reserved() && !usr_nz[0] && nor[old + 512] == 0x11 && locked_mutations(0));
    }
    fresh(); assert(!upload(0, 0x11)); reboot(); nor[SMP_USER_BASE + 20] ^= 1; reboot();
    check("invalid anchor hides samples and quarantines entire pool", smp_journal_state == SMP_JOURNAL_LOCKED && all_reserved());
    fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
    for (uint32_t k = 0; k < 59; k++) {
        int rc = ed_smp_begin(1, 256);
        if (rc) break;
        ed_smp_stage_abort(1);
    }
    writes = 0;
    check("aborted claims exhaust space safely without recycling it", ed_smp_begin(2, 256) != 0 && !writes && all_reserved());
    check("deletion works with no free audio sector", !ed_smp_erase(0) && nor[old + 512] == 0x11);
    reboot(); check("full-pool deletion remains durable", gone(0) && all_reserved());
    fresh();
    for (uint32_t i = 0; i < 60; i++) {
        if (upload(0, 0x11)) break;
        assert(!ed_smp_erase(0));
    }
    /* 42 CLAIM/PUBLISH/DELETE cycles use 126 of 127 journal records. */
    writes = 0;
    check("journal capacity refuses a new upload without programming", ed_smp_begin(1, 256) != 0 && !writes);
    assert(!ed_smp_erase(1)); writes = 0;
    check("full journal refuses deletion without erasing data", ed_smp_erase(2) != 0 && !writes);
    reboot(); check("full journal remains readable with durable deletions", gone(0) && gone(1) && smp_journal_state == SMP_JOURNAL_READY);
}
/* H1: drive the same headers through END, recovery, and playback. */
typedef struct {
    const char *name;
    uint32_t offset, size, value;
    int zone;
} h1_case_t;
#define H1_HEADER(f, v) {#f, __builtin_offsetof(smp_user_hdr_t, f), sizeof(((smp_user_hdr_t *)0)->f), (uint32_t)(v), 0}
#define H1_ZONE(f, v) {#f, __builtin_offsetof(smp_zone_t, f), sizeof(((smp_zone_t *)0)->f), (uint32_t)(v), 1}
static const h1_case_t h1_bad[] = {
    H1_HEADER(magic, 0), H1_HEADER(version, 2), H1_HEADER(nz, 0), H1_HEADER(nz, 17),
    H1_HEADER(data_len, 4096), H1_HEADER(data_len, 0),
    H1_ZONE(n, 0), H1_ZONE(n, 513), H1_ZONE(n, UINT32_MAX),
    H1_ZONE(off, 256), H1_ZONE(off, 257), H1_ZONE(off, UINT32_MAX),
    H1_ZONE(off, UINT32_MAX - 255u),
    H1_ZONE(idx, 89), H1_ZONE(idx, 255),
    H1_ZONE(rate, 0), H1_ZONE(rate, (4u << 16) + 1u), H1_ZONE(rate, UINT32_MAX),
    H1_ZONE(root16, -1), H1_ZONE(root16, 127 * 16 + 1),
    H1_ZONE(root16, -32768), H1_ZONE(root16, 32767),
    H1_ZONE(lo, 128), H1_ZONE(hi, 128), H1_ZONE(hi, 255),
    H1_ZONE(ls, 512), H1_ZONE(ls, UINT32_MAX),
    H1_ZONE(le, 512), H1_ZONE(le, UINT32_MAX), H1_ZONE(looped, 2), H1_ZONE(looped, 255)
};
#undef H1_HEADER
#undef H1_ZONE
static void h1_corrupt(smp_user_hdr_t *h, const h1_case_t *c, uint32_t zone)
{
    uint8_t *p = c->zone ? (uint8_t *)&h->zone[zone] : (uint8_t *)h;
    p += c->offset;
    if (c->size == 1) { uint8_t v = (uint8_t)c->value; memcpy(p, &v, 1); }
    else if (c->size == 2) { uint16_t v = (uint16_t)c->value; memcpy(p, &v, 2); }
    else { assert(c->size == 4); memcpy(p, &c->value, 4); }
}
static int h1_replacement_rejected(const smp_user_hdr_t *h)
{
    fresh(); assert(!upload(0, 0x11)); reboot();
    uint32_t old = smp_user_phys[0], gen = smp_user_generation[0];
    smp_zone_t zone = usr_zone[0][0];
    assert(!ed_smp_begin(0, 256)); uint32_t stage = ed_smp_stage_phys[0];
    uint8_t audio[256], packed[600]; memset(audio, 0x22, sizeof audio);
    assert(!write_page(0, 512, audio, sizeof audio));
    uint32_t w = writes, e = erases, next = smp_journal_next, stamp = smp_user_gen;
    memcpy(saved, nor, sizeof nor);
    int rc = ed_smp_end(0, packed, pack(h, sizeof *h, packed));
    int ok = rc == 2 && writes == w && erases == e && smp_journal_next == next && smp_user_gen == stamp &&
        smp_user_generation[0] == gen && smp_user_phys[0] == old && usr_nz[0] == 1 &&
        !memcmp(&zone, &usr_zone[0][0], sizeof zone) && ed_smp_erased(stage, 512);
    reboot();
    return ok && smp_journal_state == SMP_JOURNAL_READY && !smp_user_unresolved[0] &&
        smp_user_generation[0] == gen && smp_user_phys[0] == old && usr_nz[0] == 1 &&
        !memcmp(&zone, &usr_zone[0][0], sizeof zone) &&
        smp_alloc_test((stage - SMP_USER_BASE) / 4096) && !memcmp(saved, nor, sizeof nor);
}
static void h1_tests(void)
{
    char name[160];
    for (uint32_t i = 0; i < NELEM(h1_bad); i++) {
        const h1_case_t *c = &h1_bad[i];
        smp_user_hdr_t h = header(0x22); h1_corrupt(&h, c, 0);
        int ok = !smp_user_header_valid(&h, 4096 - 512) && h1_replacement_rejected(&h);
        snprintf(name, sizeof name, "H1 invalid %s value 0x%08x never publishes or replaces old audio", c->name, c->value);
        check(name, ok);
        if (c->zone) {
            h = header(0x22); h.nz = 16;
            for (uint32_t z = 1; z < 16; z++) h.zone[z] = h.zone[0];
            h1_corrupt(&h, c, 15);
            snprintf(name, sizeof name, "H1 invalid final zone %s value 0x%08x rejects entire replacement", c->name, c->value);
            check(name, !smp_user_header_valid(&h, 4096 - 512) && h1_replacement_rejected(&h));
        }
        /* Emulate an invalid record published by older firmware, with otherwise
         * valid journal, descriptor and audio. Neither playback nor recovery may
         * disagree with END, resurrect the older generation, or release claims. */
        fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
        assert(!upload(0, 0x22)); reboot(); uint32_t latest = smp_user_phys[0];
        h = header(0x22);
        if (c->zone) { h.nz = 16; for (uint32_t z = 1; z < 16; z++) h.zone[z] = h.zone[0]; }
        h1_corrupt(&h, c, c->zone ? 15 : 0); memcpy(nor + latest, &h, sizeof h);
        smp_alloc_desc_t *d = (smp_alloc_desc_t *)(nor + latest + 480);
        /* Keep H2 integrity valid so this remains an independent H1 oracle. */
        d->reserved = st_crc32(&h, sizeof h); seal_record(d);
        smp_alloc_desc_t *pub = (smp_alloc_desc_t *)(nor + SMP_USER_BASE + smp_journal_next - 32);
        pub->data_crc = d->reserved; seal_record(pub); smp_user_header_crc[0] = d->reserved;
        ok = !smp_alloc_extent_valid(latest, 0, d, smp_user_header_crc[0]);
        smp_user_scan(0); ok &= !usr_nz[0] && !usr_zone[0][0].n;
#if FELUCCA_SLICE
        ok &= !slc_get(1);
#endif
        memcpy(saved, nor, sizeof nor); reboot();
        ok &= !smp_user_phys[0] && !usr_nz[0] && smp_user_unresolved[0] &&
            smp_alloc_test((old - SMP_USER_BASE) / 4096) && smp_alloc_test((latest - SMP_USER_BASE) / 4096) &&
            locked_mutations(0) && !memcmp(saved, nor, sizeof nor);
        snprintf(name, sizeof name, "H1 recovery and playback reject %s value 0x%08x without fallback or reuse", c->name, c->value);
        check(name, ok);
    }
    /* Reversed keys, where both individual endpoints are valid MIDI notes. */
    smp_user_hdr_t h = header(0x22); h.zone[0].lo = 100; h.zone[0].hi = 99;
    check("H1 reversed key range rejects replacement", h1_replacement_rejected(&h));
    h = header(0x22); h.zone[0].ls = 200; h.zone[0].le = 199;
    check("H1 reversed in-range loop boundaries reject replacement", h1_replacement_rejected(&h));
    /* Length mismatch remains a transaction error even if its zones are valid. */
    h = header(0x22); h.data_len = 255; h.zone[0].n = 510; h.zone[0].le = 509;
    check("H1 semantic validity does not bypass BEGIN length agreement", smp_user_header_valid(&h, 3584) && h1_replacement_rejected(&h));
    for (uint32_t variant = 0; variant < 7; variant++) {
        fresh(); h = header(0x22);
        if (variant == 0) { h.zone[0].n = 1; h.zone[0].off = 255; h.zone[0].ls = h.zone[0].le = 0;
            h.zone[0].idx = 88; h.zone[0].rate = 1; h.zone[0].lo = h.zone[0].hi = 0;
            h.zone[0].pred = -32768; h.zone[0].looped = 1; }
        if (variant == 1) { h.zone[0].root16 = 127 * 16; h.zone[0].lo = h.zone[0].hi = 127;
            h.zone[0].rate = 4u << 16; h.zone[0].ls = 511; h.zone[0].pred = 32767; h.zone[0].looped = 1; }
        if (variant == 2) { h.zone[0].root16 = 15; h.zone[0].n = 511; h.zone[0].le = 510; }
        if (variant == 3) { h.nz = 16; for (uint32_t z = 1; z < 16; z++) h.zone[z] = h.zone[0]; }
        if (variant == 4) { h.nz = 2; h.zone[0].n = 400; h.zone[0].le = 399;
            h.zone[1] = h.zone[0]; h.zone[1].off = 32; }  /* legitimate overlapping audio */
        if (variant == 5) memset(&h.zone[1], 255, sizeof h.zone - sizeof h.zone[0]); /* inactive bytes ignored */
        uint8_t audio[256], packed[600]; memset(audio, 0x22, sizeof audio);
        if (variant == 6) { h.data_len = 1; h.crc = st_crc32(audio, 1); h.zone[0].n = 1; h.zone[0].le = 0; }
        int ok = smp_user_header_valid(&h, 3584) && !ed_smp_begin(0, h.data_len) &&
            !write_page(0, 512, audio, h.data_len) && !ed_smp_end(0, packed, pack(&h, sizeof h, packed));
        reboot();
        ok &= smp_user_phys[0] && usr_nz[0] == h.nz && !smp_user_unresolved[0] &&
            smp_alloc_extent_valid(smp_user_phys[0], 0, (const smp_alloc_desc_t *)(nor + smp_user_phys[0] + 480), smp_user_header_crc[0]);
        snprintf(name, sizeof name, "H1 valid boundary variant %u accepted consistently by END recovery and playback", variant);
        check(name, ok);
    }
    {
        /* A running map and a newer committed map are distinct C2 states. */
        fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t running = smp_user_phys[0];
        smp_zone_t zone = usr_zone[0][0];
        assert(!upload(0, 0x22)); uint32_t gen = smp_user_generation[0];
        assert(!ed_smp_begin(0, 256)); uint32_t stage = ed_smp_stage_phys[0];
        uint8_t audio[256], packed[600]; memset(audio, 0x33, sizeof audio);
        assert(!write_page(0, 512, audio, sizeof audio)); h = header(0x33); h.zone[0].rate = 0;
        int ok = ed_smp_end(0, packed, pack(&h, sizeof h, packed)) == 2 &&
            smp_user_generation[0] == gen && smp_user_phys[0] == running &&
            !memcmp(&zone, &usr_zone[0][0], sizeof zone);
        reboot();
        check("H1 invalid upload preserves pending committed replacement and running readers", ok &&
            smp_user_generation[0] == gen && usr_nz[0] && smp_user_phys[0] != running &&
            *fm1_xip_ptr(smp_user_phys[0] + 512) == 0x22 && smp_alloc_test((stage - SMP_USER_BASE) / 4096));
        assert(!ed_smp_erase(0)); gen = smp_user_generation[0];
        assert(!ed_smp_begin(0, 256)); assert(!write_page(0, 512, audio, sizeof audio));
        ok = ed_smp_end(0, packed, pack(&h, sizeof h, packed)) == 2 && smp_user_deleted[0] &&
            smp_user_generation[0] == gen;
        reboot();
        check("H1 invalid replacement cannot clear a committed deletion barrier", ok && gone(0) && smp_user_generation[0] == gen);
    }
    /* Bounds arithmetic stays defined even for arbitrary full-width metadata. */
    h = header(0x22); h.zone[0].off = UINT32_MAX - 255u; h.zone[0].n = 512;
    check("H1 wrapped off plus bytes is not a valid extent", !smp_user_header_valid(&h, SMP_USER_POOL_SIZE - 512));
    h = header(0x22); h.data_len = 59u * 4096u - 512u;
    h.zone[0].n = h.data_len * 2u; h.zone[0].le = h.zone[0].n - 1u;
    int ok = smp_user_header_valid(&h, h.data_len);
    h.zone[0].n++; h.zone[0].le++;
    check("H1 full dynamic audio capacity is valid but one extra nibble is not", ok && !smp_user_header_valid(&h, h.data_len));
}

/* H2 integrity: tests operate on the physical RAM-NOR journal, never the
 * browser's fixed-slot protocol mock. Fixture edits model corruption/old media. */
static int h2_upload(uint32_t k, smp_user_hdr_t *h, uint8_t byte)
{
    uint8_t audio[256], packed[600]; memset(audio, byte, sizeof audio);
    assert(h->data_len == sizeof audio); h->crc = st_crc32(audio, sizeof audio);
    if (ed_smp_begin(k, sizeof audio) || write_page(k, 512, audio, sizeof audio)) return 1;
    return ed_smp_end(k, packed, pack(h, sizeof *h, packed));
}
/* Force a chosen CRC using the four reserved bytes at offset 24. This avoids
 * assuming CRC 0 or FFFFFFFF means 'absent' in descriptor or running state. */
static void h2_force_crc(smp_user_hdr_t *h, uint32_t target)
{
    uint32_t basis[32] = {0}, mask[32] = {0}, original = st_crc32(h, sizeof *h);
    uint8_t *p = (uint8_t *)h + 24;
    for (uint32_t i = 0; i < 32; i++) {
        p[i / 8] ^= 1u << (i % 8); uint32_t v = st_crc32(h, sizeof *h) ^ original, m = 1u << i;
        p[i / 8] ^= 1u << (i % 8);
        for (int b = 31; b >= 0; b--) if (v & (1u << b)) {
            if (basis[b]) { v ^= basis[b]; m ^= mask[b]; }
            else { basis[b] = v; mask[b] = m; break; }
        }
    }
    uint32_t v = target ^ original, m = 0;
    for (int b = 31; b >= 0; b--) if (v & (1u << b)) { assert(basis[b]); v ^= basis[b]; m ^= mask[b]; }
    assert(!v);
    for (uint32_t i = 0; i < 32; i++) if (m & (1u << i)) p[i / 8] ^= 1u << (i % 8);
    assert(st_crc32(h, sizeof *h) == target);
}
static void h2_tests(void)
{
    fresh(); int ok = 1;
    for (uint32_t k = 0; k < 8; k++) assert(!upload(k, 0x11 + k));
    reboot();
    for (uint32_t k = 0; k < 8; k++) {
        smp_user_scan(k);
        const smp_alloc_desc_t *d = (const smp_alloc_desc_t *)(nor + smp_user_phys[k] + 480);
        const smp_alloc_desc_t *p = (const smp_alloc_desc_t *)(nor + SMP_USER_BASE + 64 + k * 64);
        ok &= d->version == 2 && p->version == 2 && p->data_crc == d->reserved &&
            d->reserved == st_crc32(nor + smp_user_phys[k], 480) && smp_user_header_bound[k] &&
            smp_user_header_crc[k] == d->reserved && usr_nz[k] && d->data_crc != 0;
    }
    check("H2 all eight v2 publications bind descriptor journal and running CRC", ok);
    for (uint32_t i = 0; i < 2; i++) {
        fresh(); smp_user_hdr_t h = header(0x33); h2_force_crc(&h, i ? UINT32_MAX : 0);
        assert(!h2_upload(0, &h, 0x33)); reboot();
        uint32_t len; const uint8_t *p = ed_bk_object(32, &len);
        check("H2 CRC zero and FFFFFFFF are valid protected publications", usr_nz[0] && smp_user_header_bound[0] &&
            smp_user_header_crc[0] == (i ? UINT32_MAX : 0) && p && len == 768);
    }
    /* Exhaust all 3840 bit positions, including inactive zones and reserved bytes. */
    fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0];
    smp_user_hdr_t h = header(0x22); h.zone[0].root16 = 960;
    assert(!h2_upload(0, &h, 0x22)); reboot(); uint32_t latest = smp_user_phys[0];
    memcpy(saved, nor, sizeof nor); ok = 1;
    for (uint32_t bit = 0; bit < 480 * 8; bit++) {
        memcpy(nor, saved, sizeof nor); reboot(); smp_zone_t zone = usr_zone[0][0];
        uint32_t w = writes, e = erases;
        nor[latest + bit / 8] ^= 1u << (bit % 8);
        ok &= no_exports_allow_reads(1) && smp_user_unresolved[0] && !smp_user_header_bound[0] &&
            !memcmp(&zone, &usr_zone[0][0], sizeof zone); /* exposure must not disrupt retained readers */
        reboot();
        ok &= !smp_user_phys[0] && !usr_nz[0] && smp_user_unresolved[0] && locked_mutations(0) &&
            smp_alloc_test((old - SMP_USER_BASE) / 4096) && smp_alloc_test((latest - SMP_USER_BASE) / 4096) &&
            !memcmp(nor + old, saved + old, 4096) && writes == w && erases == e;
    }
    check("H2 all 3840 single-bit header mutations block exposure recovery and sector reuse", ok);
    memcpy(nor, saved, sizeof nor); reboot();
    nor[latest + 52] &= ~0x40u; /* root 960 -> 896: semantically valid, one NOR bit cleared */
    check("H2 valid tuning corruption passes H1 but fails publication integrity", smp_user_header_valid((const smp_user_hdr_t *)(nor + latest), 3584) && no_exports_allow_reads(1));
    reboot(); check("H2 tuning corruption never falls back to original audio", !usr_nz[0] && !smp_user_phys[0] && smp_user_unresolved[0]);
    /* CRC disagreement is tested with repaired record CRCs: no accidental
     * reliance on record corruption rather than the independent journal binding. */
    for (uint32_t mode = 0; mode < 5; mode++) {
        fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0];
        assert(!upload(0, 0x22)); assert(!upload(1, 0x33)); reboot(); latest = smp_user_phys[0];
        smp_alloc_desc_t *d = (smp_alloc_desc_t *)(nor + latest + 480);
        smp_alloc_desc_t *p = (smp_alloc_desc_t *)(nor + SMP_USER_BASE + 128);
        if (mode == 0) d->reserved ^= 1;
        if (mode == 1) p->data_crc ^= 1;
        if (mode == 2) { nor[latest + 52] ^= 0x40; d->reserved = st_crc32(nor + latest, 480); }
        if (mode == 3) d->version = 1;  /* v1 descriptor under protected v2 PUBLISH */
        if (mode == 4) d->version = 3;
        seal_record(d); seal_record(p); reboot();
        check("H2 descriptor journal disagreement or non-v2 descriptor hides only affected slot", !usr_nz[0] && !smp_user_phys[0] &&
            smp_user_unresolved[0] && usr_nz[1] && smp_journal_state == SMP_JOURNAL_READY &&
            smp_alloc_test((old - SMP_USER_BASE) / 4096) && smp_alloc_test((latest - SMP_USER_BASE) / 4096) &&
            !ed_smp_begin(2, 256) && ed_smp_stage_phys[2] != old && ed_smp_stage_phys[2] != latest);
    }
    /* Current, deleted and superseded v1 history all quarantine the whole pool. */
    for (uint32_t mode = 0; mode < 3; mode++) {
        fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0];
        if (mode == 1) assert(!ed_smp_erase(0));
        if (mode == 2) assert(!upload(0, 0x22));
        assert(!upload(1, 0x33));
        smp_alloc_desc_t *d = (smp_alloc_desc_t *)(nor + old + 480);
        smp_alloc_desc_t *p = (smp_alloc_desc_t *)(nor + SMP_USER_BASE + 64);
        p->version = 1; p->data_crc = d->data_crc; seal_record(p);
        d->version = 1; d->reserved = 0; seal_record(d);
        memcpy(saved, nor, sizeof nor); reboot();
        ok = quarantined() && no_exports() && !memcmp(saved, nor, sizeof nor);
        for (uint32_t k = 0; k < 8; k++) ok &= locked_mutations(k);
        reboot();
        check("H2 mixed journals quarantine all v1 history including deleted and superseded records", ok && quarantined() && !memcmp(saved, nor, sizeof nor));
    }
    fresh(); assert(!ed_smp_begin(0, 256)); assert(!ed_smp_erase(0)); reboot();
    check("H2 v1 CLAIM DELETE and anchor without old PUBLISH remain usable", gone(0) && smp_journal_state == SMP_JOURNAL_READY && !upload(0, 0x11));
    for (uint32_t mode = 0; mode < 4; mode++) {
        fresh(); assert(!upload(0, 0x11));
        smp_alloc_desc_t *p = (smp_alloc_desc_t *)(nor + SMP_USER_BASE + (mode == 0 ? 64 : mode == 1 ? 32 : 0));
        if (mode == 2) { assert(!ed_smp_erase(0)); p = (smp_alloc_desc_t *)(nor + SMP_USER_BASE + smp_journal_next - 32); }
        p->version = mode == 0 ? 3 : 2; seal_record(p); memcpy(saved, nor, sizeof nor); reboot();
        check("H2 unknown PUBLISH CLAIM DELETE or anchor versions lock all sectors", smp_journal_state == SMP_JOURNAL_LOCKED &&
            all_reserved() && !usr_nz[0] && locked_mutations(0) && !memcmp(saved, nor, sizeof nor));
    }
    /* Running A must retain its expected CRC while B awaits reboot, even for INFO/backup. */
    fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0]; uint32_t crc = smp_user_header_crc[0];
    smp_zone_t zone = usr_zone[0][0]; assert(!upload(0, 0x22));
    smp_user_hdr_t snapshot; uint32_t len;
    ok = smp_user_running_header(0, &snapshot) && snapshot.crc == st_crc32(nor + old + 512, 256) &&
        smp_user_header_crc[0] == crc && ed_bk_object(32, &len) == nor + old && len == 768;
    smp_user_scan(0);
    check("H2 pending B never replaces running A CRC map zones or backup", ok && smp_user_phys[0] == old && usr_nz[0] && !memcmp(&zone, &usr_zone[0][0], sizeof zone));
    ed_smp_io_fail(1);
    check("H2 uncertain I/O hides metadata without XIP reads or invalidating running A", no_exports() &&
        smp_user_header_bound[0] && smp_user_header_crc[0] == crc && usr_nz[0] && !memcmp(&zone, &usr_zone[0][0], sizeof zone));
    reboot(); check("H2 B activates with its own expected CRC after reboot", usr_nz[0] && smp_user_phys[0] != old && smp_user_header_crc[0] != crc);
    assert(!ed_smp_erase(0)); assert(!upload(0, 0x33)); reboot(); latest = smp_user_phys[0];
    nor[latest + 24] ^= 1; reboot();
    check("H2 corrupted replacement preserves deletion barrier with no historical fallback", gone(0) && smp_user_unresolved[0]);
    /* An uncertain physical header readback never commits PUBLISH. */
    fresh(); assert(!upload(0, 0x11)); reboot(); old = smp_user_phys[0]; assert(!ed_smp_begin(0, 256));
    uint8_t audio[256], packed[600]; memset(audio, 0x22, sizeof audio);
    assert(!write_page(0, 512, audio, sizeof audio)); h = header(0x22);
    bad_phys = ed_smp_stage_phys[0]; memcpy(bad_sector, nor + bad_phys, sizeof bad_sector); bad_read_active = 1;
    uint32_t next = smp_journal_next;
    ok = ed_smp_end(0, packed, pack(&h, sizeof h, packed)) != 0 && !flash_ok && smp_user_io_blocked && smp_journal_next == next;
    reboot(); check("H2 physical header readback failure preserves old publication and reservation", ok && usr_nz[0] && smp_user_phys[0] == old && smp_alloc_test((bad_phys - SMP_USER_BASE) / 4096));
}

/* Public API coverage uses real command guards and physical journal storage. */
static void eight_slot_tests(void)
{
    fresh();
    int ok = SMP_USER_SLOTS == 8 && ED_BK_N == 18;
    for (uint32_t i = 0; i < 18; i++) ok &= ED_BK_IDS[i] == (i < 10 ? i : i + 22);
    for (uint32_t k = 0; k < 8; k++) {
        uint8_t begin[] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_BEGIN, k, 0, 2, 0};
        host_wire_n = 0; ed_handle(begin, sizeof begin); host_drain();
        ok &= host_wire_n == 8 && host_wire[5] == k && !host_wire[6];
        uint8_t data[256], packed[600]; memset(data, 0x11 + k, sizeof data);
        ok &= !write_page(k, 512, data, sizeof data);
        smp_user_hdr_t h = header(0x11 + k);
        uint8_t end[640] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_END, k};
        host_wire_n = 0; ed_handle(end, 5 + pack(&h, sizeof h, end + 5)); host_drain();
        ok &= host_wire_n == 8 && host_wire[5] == k && !host_wire[6];
    }
    reboot();
    uint8_t info[] = {ED_HDR0, ED_HDR1, ED_HDR2, ED_SMP_INFO};
    host_wire_n = 0; ed_handle(info, sizeof info); host_drain();
    ok &= host_wire_n == 32 && host_wire[5] == 8 && host_wire[6] == 80;
    for (uint32_t k = 0; k < 8; k++) {
        uint32_t len;
        ok &= host_wire[7 + k * 3] == 1 && !host_wire[8 + k * 3] && host_wire[9 + k * 3] == 1;
        ok &= ed_bk_object(32 + k, &len) == nor + smp_user_phys[k] && len == 768;
    }
    check("S2 command upload, reboot, INFO and stable backup IDs expose all eight slots", ok);
    memcpy(saved, nor, sizeof nor); uint32_t before = writes;
    const uint8_t commands[] = {ED_SMP_BEGIN, ED_SMP_WRITE, ED_SMP_END, ED_SMP_ERASE};
    for (uint32_t c = 0; c < 4; c++) {
        uint8_t bad[] = {ED_HDR0, ED_HDR1, ED_HDR2, commands[c], 8, 0, 2, 0, 0};
        host_wire_n = 0; ed_handle(bad, c == 0 ? 8 : c == 3 ? 5 : sizeof bad); host_drain();
        ok &= !host_wire_n;
    }
    uint32_t len; ok &= !ed_bk_object(40, &len) && !len;
    check("S2 slot eight and backup ID forty rejected without flash writes", ok && writes == before && !memcmp(saved, nor, sizeof nor));
    ok = 1;
    for (uint32_t k = 0; k < 8; k++) {
        uint32_t phys = smp_user_phys[k], crc = smp_user_header_crc[k];
        smp_zone_t z = usr_zone[k][0];
        assert(!upload(k, 0x22 + k));
        ok &= smp_user_phys[k] == phys && smp_user_header_crc[k] == crc && !memcmp(&z, &usr_zone[k][0], sizeof z);
        assert(!erase_request(k));
        ok &= !usr_nz[k] && smp_user_phys[k] == phys && !memcmp(&z, &usr_zone[k][0], sizeof z) && smp_alloc_test((phys - SMP_USER_BASE) / 4096);
    }
    check("S2 all eight running readers survive pending replacements and deletion", ok);
    reboot(); ok = 1;
    for (uint32_t k = 0; k < 8; k++) ok &= gone(k);
    check("S2 all eight durable deletes survive reboot", ok);
}

int main(void)
{
    eight_slot_tests();
    fresh(); assert(!upload(0, 0x11)); reboot(); uint32_t old = smp_user_phys[0]; smp_zone_t zone = usr_zone[0][0];
    assert(!upload(0, 0x22)); uint32_t gen = smp_user_generation[0]; memcpy(saved, nor, sizeof nor); erases = 0;
    check("ERASE before reboot deletes the pending replacement", !erase_request(0) && smp_user_generation[0] == gen + 1);
    check("deletion never erases audio or changes retained zones", !erases &&
          !memcmp(&zone, &usr_zone[0][0], sizeof zone) && !memcmp(nor + SMP_USER_BASE + 4096, saved + SMP_USER_BASE + 4096, SMP_USER_POOL_SIZE - 4096));
    reboot(); check("original C2 failure 1 is prevented", gone(0));
    reboot(); check("deletion survives repeated reboots", gone(0));
    writes = 0; check("repeated ERASE is idempotent", !erase_request(0) && !writes);
    assert(!upload(0, 0x33)); reboot(); check("new publication supersedes deletion through journal order", usr_nz[0]);
    assert(!ed_smp_erase(0)); reboot(); check("original C2 failure 2 is prevented", gone(0));
    check("all old extents remain reserved after delete and reboot", smp_alloc_test((old - SMP_USER_BASE) / 4096));
    fresh(); assert(!ed_smp_begin(0, 256)); assert(!ed_smp_erase(0));
    uint8_t packed[600]; smp_user_hdr_t h = header(0x11);
    check("ERASE cancels staging and END cannot revive it", !ed_smp_stage_sectors[0] && ed_smp_end(0, packed, pack(&h, sizeof h, packed)) != 0);
    reboot(); check("deletion of an unfinished slot is durable", gone(0));
    payload_provenance(); fault_tests(); power_tests(); quarantine_tests(); anchored_visibility_tests(); journal_rejection_tests(); h1_tests(); h2_tests();
    return failures ? 1 : 0;
}
